from django.shortcuts import render, redirect
from django.http import HttpResponse
# this is for the password hashing from hassher module we import two function
# make_password,and check_password
from django.contrib.auth.hashers import make_password, check_password
from store.models.product import Product
from store.models.category import Category
from store.models.customer import *
from django.views import View


# print(make_password('1234')) #this function make the password hashed
# this function check whther hasshed password and your passowrd matches or not return true or false
# print(check_password('123','pbkdf2_sha256$216000$SIDs707VcFN1$BUyItczyqDIYVB2QnEsMFq7g37p7/dTjR3wg8nWfi0Y='))
# Create your views here.

class Index(View):
    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')

        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity == 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1

        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        #print("Your cart : ", request.session['cart'])
        return redirect('indexpage')

    def get(self, request):
       #he hyasathi jr cart pop houn gela purn then exception raise hoiel because cart navach kahich nahiye mhnun he.
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}

        products = None
        categories = Category.get_all_categories()
        category_id = request.GET.get(
            'category')  # hi regquest url through get hoil sever then server db mdhe jaun check krel
        if category_id:
            products = Product.get_all_products_by_categoryid(category_id)
        else:
            products = Product.get_all_products()

        data = {}
        data['products'] = products
        data['categories'] = categories

        #print('Your are : ', request.session.get('email'))
        # <to display in html page we pass the dictonary variable in key value pair>
        return render(request, 'index.html', data)
        # and in the html page we iterate on dictory name products.
