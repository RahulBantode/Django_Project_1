from django.shortcuts import render, redirect
from django.http import HttpResponse
# this is for the password hashing from hassher module we import two function
# make_password,and check_password
from django.contrib.auth.hashers import make_password
from store.models.customer import *
from django.views import View


# serving the signup.html page with class name as signup
class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        mobile_no = postData.get('mobileno')
        email = postData.get('email')
        password = postData.get('password')

        # hi value navachi dictonary bnvliye jene krun kuthli field validate hoiel teva bakichya fields chi
        # value tshichya tshi tithe rahil.
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'mobile_no': mobile_no,
            'email': email
        }

        # validation of the fields....
        # mannually...we can use third party library also but currently we validate it by the manually

        error_messege = ''
        # customer class cha object create krun ghetla pahilech.
        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            mobile_no=mobile_no,
                            email=email,
                            password=password)
        # refctor code by defining the validationcustomer method.
        error_messege = self.validationCustomer(customer)

        # for saving if error messege not come then save it
        if (not error_messege):
            # here we hashhed our password.
            customer.password = make_password(customer.password)
            customer.register()
            # register is the method of Customer class where we call self.save
            # we can here also use the customer.save() but it more readable
            return redirect('indexpage')

        else:
            data = {
                'error': error_messege,
                'values': value
            }

            return render(request, 'signup.html', data)

    def validationCustomer(self, customer):
        error_messege = None

        if not customer.first_name:
            error_messege = "First Name Required !!"
        elif not customer.last_name:
            error_messege = "Last Name Required !!"
        elif not customer.mobile_no:
            error_messege = "Mobile number required !!"
        elif customer.mobile_no:
            if len(customer.mobile_no) < 10 or len(customer.mobile_no) > 10:
                error_messege = "you entered wrong mobile number"
        elif not customer.email:
            error_messege = "please entered the email address"
        elif not customer.password:
            error_messege = "please entered the password"
        elif customer.password:
            if len(customer.password) < 4:
                error_messege = "password length should be greater than 4"
        elif customer.isExists():
            error_messege = "Email address already registered"

        return error_messege
