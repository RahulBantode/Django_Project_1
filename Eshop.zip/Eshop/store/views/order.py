from django.shortcuts import render, redirect
from django.views import View
from store.models.product import Product
from store.models.order import Order
from store.models.customer import Customer

#from django.utils.decorators import method_decorator

class OrderView(View):

 #   @method_decorator(auth_middleware)  #its one way to use middleware but if want to apply it on several pages then it lengthy proc.
    def get(self,request):
        #first we get the customer id to get the order associated with that customer
        customer = request.session.get('customer_id')
        #then we call the method as get_orders_by_customer(and pass the customer_id to it)
        #which returns all the data in the form of dictonary.
        orders = Order.get_orders_by_customer(customer)

        #and at the time of render the page we pass this dictonary to the order.html page
        #and iterate all the field using for loop in html page.
        return  render(request,'order.html',{'orders': orders})
