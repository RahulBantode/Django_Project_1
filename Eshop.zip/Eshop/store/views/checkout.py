from django.shortcuts import render, redirect
from django.views import View
from store.models.product import Product
from store.models.order import Order
from store.models.customer import Customer


class Checkout(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        # customer_id hyasathi ki aapn login krtana customer_id hya field mdhech tyacha id save kela aahe session through.
        customer = request.session.get('customer_id')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))

        print(address, phone, customer, cart, products)

        #for loop hya krta ki cart mdhe jitke products astil te individually store kryache aahe so
        #if cart mdhe 3 products astil tr tevdhya veli chalel and tya idividual chi price database mdhun get keli so
        for product in products:
            order = Order(product=product,  #aapn idividual product chi id ghetoy for loop mdhun so product.
                          customer=Customer(id=customer), #its foreign key so we create on Customer object and
                                                         #id la aapn session through ghetleli id deun dili.
                          quantity=cart.get(str(product.id)), #quantity cart mdhun ghetli and product.id mdhun to number
                                                          #data type aahe so str mdhe conversion kel.
                          price=product.price,           #product table la jaun price ghetli.
                          address=address,               #data field automatically save honar.
                          phone=phone)

            order.placOrder()  #the function will have placeorder function which call to self.save() means object.save()fun.
                            #to save all the data into database.
        request.session['cart'] = {} #ethe aapn cart la empty krun takl.
        return redirect('orderpage')  #after completion task the page will redirect to same page/after the work with order
                                    #page we will redirect it to the order page.
