from django.shortcuts import render,redirect,HttpResponseRedirect
from django.http import HttpResponse
#this is for the password hashing from hassher module we import two function
#make_password,and check_password
from django.contrib.auth.hashers import check_password
from store.models.customer import *
from django.views import View


#serving the login.html page with function name as login
class Login(View):
    return_url = None
    def get(self,request):
        Login.return_url = request.GET.get('return_url')
        #print("url - ",Login.return_url)
        return render(request, 'login.html')

    def post(self,request):
        email = request.POST.get('email')
        password = request.POST.get('password')

        # to check whether the email id entered user are already exits or not.
        customer = Customer.get_customer_by_email(email)
        error_messege = None

        if customer:
            # first args= password which enterd by user and second arg= customer table mdhe tya email id cha hasshed password
            # if true asel tr succes other wise false
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer_id'] = customer.id
                request.session['email'] = customer.email

                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('indexpage')
            else:
                error_messege = "Email or password are invalid !!"
        else:
            error_messege = "Email or password are invalid !!"

        return render(request, 'login.html', {'error': error_messege})

def logout(request):
    request.session.clear()
    return redirect('loginpage')
