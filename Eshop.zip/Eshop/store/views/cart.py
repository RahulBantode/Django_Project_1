from django.shortcuts import render,redirect
from django.views import View
from store.models.product import Product

class Cart(View):
    def get(self,request):
        #khalil 3 lines code jr session logout kel tr cart challa jaiel r8 then AttributeError raise hoiel so
        #aapn asa code kela tyane error yenar nahi
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}

        ids = list(request.session.get('cart').keys())
        products = Product.get_products_by_id(ids)
        #print(products)
        return render(request,'cart.html' , {'products':products})