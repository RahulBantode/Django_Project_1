from django.conf.urls import url  #this is for to use the url function.
from django.contrib import admin
from django.urls import path
from .views.login import Login ,logout
from .views.signup import Signup
from .views.index import Index
from .views.cart import Cart
from .views.checkout import Checkout
from .views.order import OrderView
from store.middleware.authorization import auth_middleware
#to write middleware in urls.py file is best way

urlpatterns = [
    path('', Index.as_view(), name="indexpage"),
    # name property which is work like url so at the time of redirect func we can use it.
    path('signup', Signup.as_view(), name="signuppage"),
    url('login', Login.as_view(), name="loginpage"),  #we using querry string so in my case path fun no supoort so i use url.
    path('logout',logout , name="logoutpage"),
    path('cart', Cart.as_view(), name='cartpage'),
    path('check-out' , Checkout.as_view(),name="checkoutpage"),
    path('order' , auth_middleware(OrderView.as_view()),name="orderpage")
]
