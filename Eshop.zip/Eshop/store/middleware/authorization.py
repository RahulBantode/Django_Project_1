from django.shortcuts import redirect,HttpResponseRedirect

def auth_middleware(get_response):
    #one time configuration and initialization

    def middleware(request):
        #code to be executed for each request before
        #the view (and later middleware) are called.
        #print(request.session.get('customer_id'))
        returnurl = request.META['PATH_INFO']
       # print(request.META['PATH_INFO']) by the help of this method we can get the existing url.

        if not request.session.get('customer_id'):
            return redirect(f"loginpage?return_url={returnurl}")

        response = get_response(request)

        #code to be executed for each request/response after the view is called

        return response

    return middleware