from django import template

register = template.Library() #L of Library function should be capital

#this for checking the product id from the html page and product from cart
#if the product are in cart then it will return true and display the + 1 in cart - wala form
#if it will return false then Add to cart wala form show hoiel.
#it used in index.html
@register.filter(name = 'is_in_cart')
def is_in_cart(product , cart):
    keys = cart.keys()

    for id in keys:
        if int(id) == product.id:
            return True

    return False

#this will return the how many quantity for individual product are available.
#it used in index.html page
@register.filter(name = 'cart_quantity')
def cart_quantity(product , cart):
    keys = cart.keys()

    for id in keys:
        if int(id) == product.id:
            return cart.get(id)

    return 0

#it used in cart.html page
@register.filter(name = 'total_price')
def total_price(product , cart):
    #aaplyala price mahitiy and price * quatitiy keli tr total price milele
    # so second aapn vrch function dil tyane aaplya product chi quantity milel so tyala call kel
    return product.price * cart_quantity(product,cart)

#it used in cart.html page
@register.filter(name='total_product_quantity')
def total_product_quantity(product , cart):
    sum = 0
    for p in product:
        #ethe aapn srv quantitiy chi berij keli aahe ek product with tyache quantity + next prod.
        sum = sum + cart_quantity(p, cart)

    return sum

#it used in cart.html page
@register.filter(name = 'total_cart_price')
def total_cart_price(product , cart):
    sum = 0
    for p in product:
        #ethen aaplya srv product chi sum pahije means ek product + price*quantity
        #so vr function mdhe aapn price*quantity kadhli so aapn ethe ek product p
        #and then te vrch function passs krun dil.
        sum = sum + total_price(p , cart)

    return sum

#Now currency filter for displaying ruppes sign after the price.
#it used in cart.html page

@register.filter(name="currency")
def currency(number):
    return " ₹ "+str(number)+" -INR"

#this is used in the order.html page to 
#multiply the quantity as first arg and price as second arg for specific product order.
@register.filter(name="multiply")
def multiply(number , number1):
    return number * number1