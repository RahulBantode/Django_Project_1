from django.db import models
from .product import Product
from .customer import Customer
import datetime

class Order(models.Model):
    product = models.ForeignKey(Product , on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    price = models.IntegerField()
    date = models.DateField(default=datetime.datetime.today)
    address = models.CharField(max_length=50,default=" ")
    phone = models.CharField(max_length=50,default=" ")
    status = models.BooleanField(default=False)

    def placOrder(self):
        self.save()

    @staticmethod
    def get_orders_by_customer(customer_id):
        # \ means we can write the same line statment on next line like verbose field in regex pythoon module.
        return Order \
               .objects \
               .filter(customer = customer_id).order_by("-date")
        #static method which returns the data from order table acording to the customer id which we are passed.
        #if the customer id matcches then it returns all the field and which we are collected in dictonary .
       # now we display all the field by date so order_by is the method type - sign means show order in reverse
