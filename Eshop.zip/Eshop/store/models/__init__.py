from .product import Product  #first models name is import here
from .category import Category #second models name is import here
from .customer import Customer #third models name is import here
from .order import Order #fourth models name is import here

