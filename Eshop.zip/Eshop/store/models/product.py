#importing the database related files from modelfrom django.db import models
from django.db import models
from .category import Category
#means in the database table product we write the fields in the table having the columns
#model means table in database

#here our product is sub class inherited from models.Model
class  Product(models.Model):
    name = models.CharField(max_length=50)
    price = models.IntegerField(default=0)
#   <field name> <modelclass>.<class><module which are to foreign key> <on delete jr
    category = models.ForeignKey(Category, on_delete=models.CASCADE,default='', null=True, blank=True) #this are the foreiegn key
    description = models.CharField(max_length=200,default=' ')
    image = models.ImageField(upload_to="uploads/products/")

#models means simply the database fields into which admin are going add the data. by using sqlite.com

#for collecting the product from database following code are there...we can write it in view.py page also

    @staticmethod
    def get_all_products():
        return Product.objects.all()  #to return all the product from product table from database we use this method

    @staticmethod
    def get_all_products_by_categoryid(category_id):
        if category_id:
            return Product.objects.filter(category = category_id)
        else:
            return Product.get_all_products()

    #this method to display the products in cart.then we import this method into the cart.py file.
    @staticmethod
    def get_products_by_id(ids):
        return Product.objects.filter(id__in = ids)