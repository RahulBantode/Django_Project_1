from django.contrib import admin
from .models.product import Product     #first model
from .models.category import Category   #second model
from .models.customer import Customer  #third model
from .models.order import Order  #fourth model

#this class for displaying actual name into the admin table
class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'price', 'category', 'image']

class AdminCategory(admin.ModelAdmin):
    list_display = ['name']

class AdminCustomer(admin.ModelAdmin):
    list_display = ['first_name','last_name','mobile_no','email','password']

class AdminOrder(admin.ModelAdmin):
    list_display = ['product' , 'customer' , 'quantity' , 'price' , 'date' , 'address' , 'phone']

# Register your models here.
admin.site.register(Product,AdminProduct)  #first model nameed as Product is registered here
admin.site.register(Category,AdminCategory) #Second model named as Category is registered here.
admin.site.register(Customer,AdminCustomer) #third model named as Customer is registered here then we can see it in
                                            #admin pannel.
admin.site.register(Order,AdminOrder) #register the order model here